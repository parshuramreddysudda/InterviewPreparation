package springdemo;


public class Alien {

	public void Show() {
		System.out.println(" I am the hero");
	}
}
