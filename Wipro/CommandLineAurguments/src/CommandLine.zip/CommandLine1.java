
public class CommandLine1 {
	public static void main(String b[]){
        System.out.println(b[0]+" Technologies "+b[1]);
        
   }
}
 