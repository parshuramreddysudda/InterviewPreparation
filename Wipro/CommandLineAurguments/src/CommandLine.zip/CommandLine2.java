
public class CommandLine2 {
	public static void main(String b[]){
		
		int a=Integer.parseInt(b[0])+Integer.parseInt(b[1]);
        System.out.println("The sum of "+b[0]+" and "+b[1]+" is "+a);
        
   }
}
