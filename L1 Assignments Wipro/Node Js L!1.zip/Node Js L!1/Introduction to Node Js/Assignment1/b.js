

console.log('Hello'.red);
console.log('Welcome to Node JS'.rainbow);
