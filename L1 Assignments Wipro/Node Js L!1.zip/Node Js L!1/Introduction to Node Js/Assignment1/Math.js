exports.add = function (x, y) {
    return x + y;
};
  
exports.subtract = function (x, y) {
    return x - y;
};
  
exports.multiply = function (x, y) {
    return x * y;
};
  
exports.Division = function (x, y) {
    return x / y;
};