
for(var i = 0; i < 100; i++){
  setTimeout(function(){
    console.log('Welcome to Node JS');
  },1000);
}
