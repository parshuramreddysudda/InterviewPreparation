
var Math= require('./Math');
var a=20,b=50;
console.log("Addition:- " +Math.add(a,b));
console.log("Subtraction:- " +Math.subtract(a,b));
console.log("Multiplication:- " +Math.multiply(a,b));
console.log("Division:- " +Math.Division(a,b));
