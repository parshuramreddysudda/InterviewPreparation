telnet 127.0.0.1 3000;

openssl s_client -connect 127.0.0.1:3000